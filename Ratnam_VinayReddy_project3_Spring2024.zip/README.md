Name: Vinay Reddy Ratnam
Section: 10793
UFL Email: ratnam.v@ufl.edu
System: MacOS Sonoma 14.0
Compiler: Clang Version 15.0.0
SFML version: 2.6.1
IDE: Clion
Other notes: None